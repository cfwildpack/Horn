function showMessage() {
    alert("Selamat datang di website Tanduk! 🔥");
}
