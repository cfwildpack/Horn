# Tanduk Website Theme

Template website bertema tanduk dengan nuansa gelap dan aksen merah.

## Fitur
- Dark aggressive theme
- Responsive layout
- Modern design
- Siap upload ke GitHub

## Cara Menjalankan
1. Extract file zip
2. Buka `index.html` di browser

---
Project siap untuk commit 🚀
